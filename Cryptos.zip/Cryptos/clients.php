<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cryptos : Accueil</title>
	<link rel="stylesheet" href="css/style.css.css">
</head>

<body>

	<section class="top-page">
		<header>
			<img src="images/logo2.png"alt="logo du site">
			<nav class="ENTETTE">
				<li> Accueil</li>
				<li>Boutique</li>
				<li>S'identifier</li>
			</nav>
		</header>
		<div class="landing-page">
			<h1 class="slogan">La boutique n°1 sur la cryptomonnaie</h1>
		</div>
	</section>

	        <h1 align=center>s'incrire</h1><br>
		<p class="lien"><a href="index.php">RETOUR</a></p>
		<h2 class="titre">Mes coordonnées </h2>
		<br>
		<form name="inscription" method="post" action="clients.php">
			<h2>Votre nom<input type="text" name="nomclient"><br>
				Votre prénom <input type="text" name="prenomclient"><br>
				Votre adresse email <input type="text" name="emailclient"><br>
				Votre Pseudo <input type="text" name="pseudoclient"><br>
				Choississez un mot de passe <input type="text" name="passwordclient"><br>
			</h2>
			<input type="submit" name="valider" value="SOUMETTRE">
		</form>
	 	<?php
            //On se connecte
            connectMaBase();
			
            //On prépare la requête SQL qui récupère les champs
            $sql = 'SELECT * FROM clients';
            /* On lance la requête (mysql_query) 
            et on impose un message d'erreur si la requête ne passe pas (or die) */ 
            $req = mysql_query($sql) or die('Erreur SQL !<br />'.$sql.'<br />'.mysql_error()); 
            //boucle qui organise $req en tableau associatif $date['champ']
			//On scanne le résultat et on construit chaque option avec
			echo '<section>';
			echo "<table border>
					<tr>
						<th> Voici ton Numéro client : </th>
						<th> Voici ton Numéro client : </th>
						<th> Voici ton Numéro client : </th>
						<th> Voici ton Numéro client : </th>
					</tr>";
  
			while ($data = mysql_fetch_array($req)) {
			echo '<tr><td>'.$data['nomclient'].'</td><td>'.$data['prenomclient'].'</td><td>'.$data['emailclient'].' min
			</td><td>'.$data['pseudoclient'].'</td><td>'.$data['passwordclient'];
			}
			echo "</table>";
			echo '</section>';    
			//On libère mysql de cette première requête, mais on garde la variable PHP $data accessible
            mysql_free_result ($req); 
            //On ferme 
            mysql_close (); 
		?> 
	</body>
</html>
	 