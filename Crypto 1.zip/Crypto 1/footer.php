	    <footer class="footer section text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <ul class="social-media">
            <li>
              <a href="https://www.instagram.com/">
                <i class="fa fa-instagram"></i>
              </a>
            </li>
            <li>
              <a href="https://www.twitter.com/">
                <i class="fa fa-twitter"></i>
              </a>
            </li>
            <li>
              <a href="https://www.pinterest.com/">
                <i class="fa fa-pinterest"></i>
              </a>
            </li>
          </ul>
          <ul class="footer-menu">
            <li>
              <a href="">Contact</a>
            </li>
            <li>
              <a href="">Livraison</a>
            </li>
            <li>
              <a href="">Mentions légales</a>
            </li>
            <li>
              <a href="">Protection des données personnelles</a>
            </li>
          </ul>
          <p class="copyright-text">Copyright © 2021 All Rights Reserved. Traphouse </p>
        </div>
      </div>
    </div>
  </footer>
</body>
	
	
</html>
